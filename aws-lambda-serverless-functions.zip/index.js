require('dotenv').config();

const express = require('express');
const serverless = require('serverless-http');
const app = express();
const bodyParser = require('body-parser');
// const port = 3000;

const cors = require('cors');

const { Configuration, OpenAIApi } = require('openai');

app.use(express.json());
app.use(bodyParser.json());
app.use(cors());

const configuration = new Configuration({
  organization: 'org-Afl5yl2Yr3FiTJMEqEHM1tKn',
  apiKey: process.env.OPENAI_API_KEY,
});

const openai = new OpenAIApi(configuration);

// base route "/" won't work in AWS Lambda serverless function

//test
app.get('/test', (req, res) => {
  res.send('Hello World!');
});

//preggo
app.post('/preggo', async (req, res) => {
  try {
    const { item } = req.body;

    const completion = await openai.createChatCompletion({
      model: 'gpt-3.5-turbo',
      // model: 'gpt-4',
      messages: [
        {
          role: 'user',
          content: `Can pregnant women eat ${item}?`,
        },
      ],
    });

    res.json({
      completion: completion.data.choices[0].message,
    });
  } catch (e) {
    console.log(e);
    res.status(500).json({
      error: e,
    });
  }
});

// app.listen(port, () => {
//   console.log(`Example app listening at http://localhost:${port}`);
// });

module.exports.handler = serverless(app);
